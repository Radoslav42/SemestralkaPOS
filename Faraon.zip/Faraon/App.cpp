﻿// Faraon.cpp : Defines the entry point for the application.
//

#include "Includes.h"
#include "Game.h"
using namespace std;
/*
#pragma pack(1)   // this helps to pack the struct to 5-bytes
struct packet {
	int a;
	int b;
	char meno[256];
};
#pragma pack(0)   // turn packing off
*/
int main(int argc, char* argv[])
{
	//este odladit, ci vsetko funguje
	/*char b[256] = "Ahoj";
	string a = "Ahoj";
	if (a.compare(b) == 0)
	{
		a = "b";
	}*/
	
	Game game(argc < 2 ? 4502/*or another, same as is set on client for connection.*/ : atoi(argv[1]));
	/*int sockfd, newsockfdPlayer1, newsockfdPlayer2;
	socklen_t cli_lenPlayer1, cli_lenPlayer2;
	struct sockaddr_in serv_addr, cli_addrPlayer1, cli_addrPlayer2;
	int n;
	char buffer[256];


	bzero((char*)&serv_addr, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;

	if (argc < 2)
	{
		serv_addr.sin_port = htons(4502);
	}
	else
	{
		serv_addr.sin_port = htons(atoi(argv[1]));
	}

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
		if (sockfd < 0)
		{
			perror("Error creating socket");
			return 1;
		}

	if (bind(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0)
	{
		perror("Error binding socket address");
		return 2;
	}

	listen(sockfd, 5);



	cli_lenPlayer1 = sizeof(cli_addrPlayer1);

	newsockfdPlayer1 = accept(sockfd, (struct sockaddr*)&cli_addrPlayer1, &cli_lenPlayer1);
		if (newsockfdPlayer1 < 0)
		{
			perror("ERROR on accept");
			return 3;
		}
	cli_lenPlayer1 = sizeof(cli_addrPlayer2);*/
	/*n = read(newsockfdPlayer1, buffer, 255);
	if (n < 0)
	{
		perror("Error reading from socket");
		return 4;
	}
	n = read(newsockfdPlayer1, buffer, 255);
	if (n < 0)
	{
		perror("Error reading from socket");
		return 4;
	}*/



	/*newsockfdPlayer2 = accept(sockfd, (struct sockaddr*)&cli_addrPlayer2, &cli_lenPlayer2);
	if (newsockfdPlayer2 < 0)
	{
		perror("ERROR on accept");
		return 3;
	}*/
	/*packet p;
	bzero(buffer, 256);
	n = read(newsockfdPlayer1, &p, sizeof(struct packet));
		if (n < 0)
		{
			perror("Error reading from socket");
			return 4;
		}
	//printf("Here is the message: %s\n", buffer);
	n = read(newsockfdPlayer1, &p, sizeof(struct packet));
	if (n < 0)
	{
		perror("Error reading from socket");
		return 4;
	}
	//printf("Here is the message: %s\n", buffer);
		const char* msg = "I got your message";
		
		p.a = 50;
		p.b = 10;
		string s = "H";
		s.copy(p.meno, 5);
		//strcpy(p.meno, "Hovno");
		n = write(newsockfdPlayer1, &p, sizeof(struct packet));
		if (n < 0)
		{
			perror("Error writing to socket");
			return 5;
		}

	close(newsockfdPlayer1);
	close(sockfd);
	*/
	return 0;
}
