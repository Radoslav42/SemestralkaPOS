#pragma once
#include "Includes.h"
#include "Player.h"
using namespace std;
namespace structures
{
	// struktura, ktora sa posiela smerom zo servera ku klientom
	struct GameReport
	{
		//vsetci pripojeni hraci
		int numberPlayers;
		structures::PublicPlayer players[4];
		//pocet vyhodenych kariet na kope
		int numberThrowedCards;
		CardType throwedCards[32];
		// pocet dostupnych kariet k potiahnutiu
		int numberCardsForPull;
		// pocet kariet k potiahnutiu 
		int numberCardsToPull;
		// pocet stopakov
		int numberStoppedPlayers;
		// isPlayingRound
		bool isPlayingRound;
	};
	//pomocna struktura v metode Match, kde typ a colo su cisla od 1 po 4, ich vynasobenim a naslednym pretipovanim na enum CardType dostaneme prislusny typ karty
	struct Card
	{
		int type;
		int color;
	};
}
class Game
{
private:
	vector<Player*> players;
	vector<Player*> waitingPlayersForNextRound;
	Player* currentPlayer;
	// vylozenie kariet, ktore tvoria podmienku nasledujucemu/cim hracom (vylozenie 7-kariet alebo stopakov)
	int numberCardsToPull;
	int numberStoppedPlayers;
	vector<CardType> cardsForPull;
	vector<CardType> throwedCards;
	thread tInitializePlayers;
	mutex _mutex;
	condition_variable conditionSignalPlayer_WaitGame;
	condition_variable conditionSignalGame_WaitPlayer;
	void Run();
	void InitializeCards();
	void InitializePlayers();
	bool CanRunGame();
	bool IsCorrectThrow(vector<CardType> cardTypes, int size);
	void UpdateCurrentPlayer();
	//server-socket
	sockaddr_in serv_addr;
	int sockfd;
	bool isPlayingRound;
public:
	Game(int port);
	~Game();
	int GetRandomInt(int from, int to);
	double GetRandomDouble(double from, double to);
	structures::GameReport CreateGameReport();
	bool IsCurrentPlayer(Player* player);
	bool IsGameOver(Player* player);
	bool SendGameReportToAllPlayer();
	bool getIsPlayingRound();
	void LeaveGame(Player* player);
	bool WantAllPlayersPlay();
	bool MatchCards(CardType cardType1, CardType cardType2, bool matchOnlyType);
};

////na klientovi treba spravit: receive pre GameReport a aktualizovat uzivatelske rozhranie, send pre poslanie struktury PrivatePlayer



//pracuje to vlastne tak, ze objekt hra posiela reporty(GameReport) klientom, a klienti poslielaju struktury(PrivatePlayer), ktore primame v jednotlivych objektoch Hracov v metode Run, nasledne ked obdrzime strukturu PrivatePlayer
//zavolame signal pre odcakanie vlakna v metode Run objektu Game, a ten zas  posiela reporty(GameReport) klientom, a v cykle