#include "Player.h"
#include "Game.h"
Player::Player(Game* game, int sockfd, string name, mutex* _mutex, condition_variable* conditionSignalPlayer_WaitGame, condition_variable* conditionSignalGame_WaitPlayer, int sockfdPlayer, socklen_t cli_lenPlayer, sockaddr_in cli_addrPlayer)
{
	this->game = game;
	this->sockfd = sockfd;
	this->name = name;
	this->_mutex = _mutex;
	this->sockfdPlayer = sockfdPlayer;
	this->cli_lenPlayer = cli_lenPlayer;
	this->cli_addrPlayer = cli_addrPlayer;
	this->conditionSignalPlayer_WaitGame = conditionSignalPlayer_WaitGame;
	this->conditionSignalGame_WaitPlayer = conditionSignalGame_WaitPlayer;
	t = thread(&Player::Run, this);
}
Player::~Player()
{
	close(sockfdPlayer);
}
string Player::getName()
{
	return name;
}

bool Player::WantPlay()
{
	return wantPlay;
}

structures::PrivatePlayer Player::getPrivatePlayer()
{
	return privatePlayer;
}

int Player::getNumberCards()
{
	return cards.size();
}

void Player::AddCard(CardType card)
{
	cards.push_back(card);
}

void Player::RemoveCard(CardType card)
{
	for (int i = 0; i < cards.size(); i++)
	{
		if (cards[i] == card)
		{
			cards.erase(cards.begin() + i);
			break;
		}
	}
}

bool Player::ReportGame(structures::GameReport gameReport)
{
	int n = write(sockfdPlayer, &gameReport, sizeof(struct structures::GameReport));
	if (n < 0)
	{
		perror("Error writing to socket");
		return false;
	}
	return true;
}

bool Player::SendPrivatePlayer()
{
	int n = write(sockfdPlayer, &privatePlayer, sizeof(struct structures::PrivatePlayer));
	if (n < 0)
	{
		perror("Error writing to socket");
		return false;
	}
	return true;
}

bool Player::UpdatePrivatePlayer()
{
	int n = read(sockfdPlayer, &privatePlayer, sizeof(struct structures::PrivatePlayer));
	if (n < 0)
	{
		perror("Error reading from socket");
		return false;
	}
	return true;
}

int Player::getSockfdPlayer()
{
	return sockfd;
}

void Player::Run()
{

	// poslanie spravy GameReport

	// cakanie na hraca, az kym nepotvrdi, ze chce zacat hrat
	// ked ziskam hocikaju spravu od hraca(na klientovi sa osetri, ze co ma urobit, aby sa 
	// tato sprava poslala) tak berem to, ze potvrdzuje, ze chce zacat hrat

	char message[256];
	int n = read(sockfdPlayer, message, 256);
	if (n < 0)
	{
		perror("Error reading from socket");
	}
	wantPlay = true;
	do {
		//notifikujem hru, ze sa zmenil stav jedneho hraca, ze chce zacat hrat hru, aby skotrolovala,
		//ci tak urobili aj ostatni hraci a mohlo sa zacat hrat
		conditionSignalPlayer_WaitGame->notify_one();
		//cakanie na hru, kym rozda karty a nastavi aktualneho hraca (hra hracov notifikuje v pripade,
		//ze vsetci potvrdili, ze chcu zacat hrat a zaroven je splnena podmienka poctu hracov
		unique_lock<mutex> lock(*_mutex);//zaroven uz zamkne
		conditionSignalGame_WaitPlayer->wait(lock);
		//od tialto sa uz v hre spustila metoda Run a z nej sa volala predchadzajuca notifikacia
		//ReportGame(game->CreateGameReport());
		//inicializacia PrivatePlayer po rozdani kariet pre herne kolo, nasledne sa posle hracovi, aby vedel, ake ma karty
		//InitializePrivatePlayer();
		// nasledne PrivatePlayer sa posle hracovi, aby vedel, ake ma karty
		//SendPrivatePlayer();
		_mutex->unlock();
		PlayGameRound();
		//ak som vyhral, pripisem si pocet vyhier
		if (cards.size() == 0)
			numberWins++;
		//budem sa len pozerat, ak este hra neskoncila, ako ostatni skoncia a kto prehra, ak chcem, ale to sa uz posobenia do hry netyka a neovlyvnuje ju, takze tu hrac so vstupom konci, ale
		// pokial chce stale hrat, tak moze pockat na dalsie kolo hry, na klientovi sa ho spyta, ci chce pokracovat dalej v hrani
		wantPlay = false;
		while (game->getIsPlayingRound())
		{
			char message[256];
			int n = read(sockfdPlayer, message, 256);
			if (n < 0)
			{
				perror("Error reading from socket");
			}
			if (message[0] == 'y')
			{
				wantPlay = true;
			}
			else
			{
				wantPlay = false;
			}
			// v pripade, ak by sme do buducna chceli este spravit, ze pocas hrania by sa hraci rozhodni, ze uz hrat nechcu a opustia hru predcasne, tak by sme na to nejakym sposobom reagovali
			_mutex->unlock();
		}
	} while (wantPlay);
}

void Player::PlayGameRound()
{
	while (cards.size() > 0)
	{
		_mutex->lock();
		// kontrola, ci som prehral
		if (game->IsGameOver(this))
		{
			_mutex->unlock();
			break;
		}
		// kontrola, ci som na rade
		if (game->IsCurrentPlayer(this))
		{
			ReportGame(game->CreateGameReport());
			//iba ak som aktualny(som na rade) hrac, tak len vtedy volam funckiu read, pre ocakavanie aktivity od hraca (cize ziskanie struktury PrivatePlayer)
			//nastavenie privatePlayer na privatePlayer-a z metody read
			UpdatePrivatePlayer();
			// aktualizacia objektu Player zo struktury PrivatePlayer, ktora prisla od kienta na podnet hraca
			_mutex->unlock();
			//notifikujeme hru o tom, ze prebehla aktualizacia objektu Player zo struktury PrivatePlayer, aby hra na to mohla zareagovat
			conditionSignalPlayer_WaitGame->notify_one();
		}
		else
		{
			_mutex->unlock();
		}
		unique_lock<mutex> lock(*_mutex);//zaroven uz zamkne
		conditionSignalGame_WaitPlayer->wait(lock);
		ReportGame(game->CreateGameReport());
	}
}

void Player::InitializePrivatePlayer()
{
	strcpy(privatePlayer.name, name.c_str());
	privatePlayer.numberCards = cards.size();
	for (int i = 0; i < cards.size(); i++)
	{
		privatePlayer.cards[i] = cards[i];
	}
	privatePlayer.wantPlay = wantPlay;
	privatePlayer.numberThrowedCards = 0;
}
vector<CardType> Player::getCards()
{
	return cards;
}
//karty aktualizovat, vyuzit numberthrowedCards, ked hrac nevyhodil ziadne karty, tak server bude, ak si mal tahat, tak mu
//pripocita karty(napr. ak mu napalil predch. hrac, alebo ak mal vylozit kartu a nemal aku(nesadla mu)