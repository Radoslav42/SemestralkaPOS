#pragma once
#include "Includes.h"
#include "Card.h"
using namespace std;
namespace structures
{
	// 1. pripad: struktura, ktora sa vyuzije samostatne(jedna sa posle) v pripade, ze sa posiela smerom od klienta k serveru, 
	// ako report o tom, co klient urobil(napr. ze klikol na tlacidlo "chcem zacat hrat" alebo ze vyhodil karty a pod.),
	// pozn. zaslanie mena este nesuvisi s existenciou hraca, nakolko metoda Run objektu Player nebezi, lebo este nebol objekt Player vytvoreny, takze sa tato struktura neposiela
	// alebo naopak zo servera na klienta, v specialnych pripadoch, ked hrac na nasledujuceho hraca pouzije sedmove karty a suhrasi z ich tahanim, ak sa nechce prebit, alebo nema na prebitie prislusne karty
	
	struct PrivatePlayer
	{
		char name[256];
		bool wantPlay;
		//karty
		int numberCards;
		CardType cards[32];
		int numberThrowedCards;
		CardType throwedCards[32];
	};
	// 2. pripad, ked po uskutocneni 1. pripadu, ked uz dorazila sprava od klienta na server, sa struktura GameReport posiela od servera smerom ku vsetkym klientom o zmene, co sa stalo
	struct PublicPlayer
	{
		char name[256];
		int sockfd;
		bool wantPlay;
		bool isCurrent;
		//karty
		int numberCards;
	};
	
}
class Game;
namespace structures
{
	struct GameReport;
}
class Player
{
private:
	Game* game;
	string name;
	vector<CardType> cards;
	bool wantPlay;
	int numberWins;
	int sockfd;
	//posledna zaznamenana aktivita hraca
	structures::PrivatePlayer privatePlayer;
	thread t;
	mutex* _mutex;
	condition_variable* conditionSignalPlayer_WaitGame;
	condition_variable* conditionSignalGame_WaitPlayer;
	//connenction-socket
	int sockfdPlayer;
	socklen_t cli_lenPlayer;
	sockaddr_in cli_addrPlayer;
	void Run();
	void PlayGameRound();
public:
	Player(Game* game, int sockfd, string name, mutex* _mutex, condition_variable* conditionSignalPlayer_WaitGame, condition_variable* conditionSignalGame_WaitPlayer, int sockfdPlayer, socklen_t cli_lenPlayer, sockaddr_in cli_addrPlayer);
	~Player();
	string getName();
	bool WantPlay();
	structures::PrivatePlayer getPrivatePlayer();
	int getNumberCards();
	void AddCard(CardType card);
	void RemoveCard(CardType card);
	bool ReportGame(structures::GameReport gameReport);
	bool SendPrivatePlayer();
	bool UpdatePrivatePlayer();
	int getSockfdPlayer();
	void InitializePrivatePlayer();
	vector<CardType> getCards();
};