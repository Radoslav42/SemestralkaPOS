#include "Game.h"
using namespace std;

void Game::InitializeCards()
{
    cardsForPull.push_back(CardType::Red_VII);
    cardsForPull.push_back(CardType::Ball_VII);
    cardsForPull.push_back(CardType::Acorn_VII);
    cardsForPull.push_back(CardType::Green_VII);
    cardsForPull.push_back(CardType::Red_VIII);
    cardsForPull.push_back(CardType::Ball_VIII);
    cardsForPull.push_back(CardType::Acorn_VIII);
    cardsForPull.push_back(CardType::Green_VIII);
    cardsForPull.push_back(CardType::Red_IX);
    cardsForPull.push_back(CardType::Ball_IX);
    cardsForPull.push_back(CardType::Acorn_IX);
    cardsForPull.push_back(CardType::Green_IX);
    cardsForPull.push_back(CardType::Red_X);
    cardsForPull.push_back(CardType::Ball_X);
    cardsForPull.push_back(CardType::Acorn_X);
    cardsForPull.push_back(CardType::Green_X);
    cardsForPull.push_back(CardType::Red_Bottom);
    cardsForPull.push_back(CardType::Ball_Bottom);
    cardsForPull.push_back(CardType::Acorn_Bottom);
    cardsForPull.push_back(CardType::Green_Bottom);
    cardsForPull.push_back(CardType::Red_Top);
    cardsForPull.push_back(CardType::Ball_Top);
    cardsForPull.push_back(CardType::Acorn_Top);
    cardsForPull.push_back(CardType::Green_Top);
    cardsForPull.push_back(CardType::Red_King);
    cardsForPull.push_back(CardType::Ball_King);
    cardsForPull.push_back(CardType::Acorn_King);
    cardsForPull.push_back(CardType::Green_King);
    cardsForPull.push_back(CardType::Red_Stop);
    cardsForPull.push_back(CardType::Ball_Stop);
    cardsForPull.push_back(CardType::Acorn_Stop);
    cardsForPull.push_back(CardType::Green_Stop);
}
void Game::Run()
{
    isPlayingRound = true;
    //refresh kariet a zamiesanie kariet
    vector<CardType> localCards;
    if (cardsForPull.size() != 32)
    {
        for (CardType card : throwedCards)
        {
            cardsForPull.push_back(card);
        }
        throwedCards.clear();
        for (Player* player : players)
        {
            vector<CardType> playerCards = player->getCards();
            for (CardType card : playerCards)
            {
                cardsForPull.push_back(card);
            }
            playerCards.clear();
        }
    }
    for (int i = 31; i >= 0; i--)
    {
        int index = GetRandomInt(0, i);
        CardType card = cardsForPull[index];
        localCards.push_back(cardsForPull[index]);
        cardsForPull.erase(cardsForPull.begin() + index);
    }
    for (CardType card : localCards)
    {
        cardsForPull.push_back(card);
    }
    localCards.clear();
    //rozdanie kariet
    for (int i = 0; i < 5; i++)
    {
        _mutex.lock();
        for (Player* player : players)
        {
            player->AddCard(cardsForPull[cardsForPull.size() - 1]);
            cardsForPull.pop_back();
        }
        _mutex.unlock();
    }
    //vyhodenie jednej karty
    throwedCards.push_back(cardsForPull[cardsForPull.size() - 1]);
    cardsForPull.erase(cardsForPull.begin() + cardsForPull.size() - 1);
    //nastavenie aktualneho hraca
    currentPlayer = players[GetRandomInt(0, players.size() - 1)];
    // odomknutie vsetkych hracov, ktory cakaju, ze mozu zacat vyhadzovat svoje karty (dotazovat spravy po kientovi, ktory da znat, ktore karty chce vyhodit)
    conditionSignalGame_WaitPlayer.notify_all();
    unique_lock<mutex> lock(_mutex);//zaroven uz zamkne
    //musim to odtialto poslat vsetkym hracom, aj inicializovat a poslat struktury, pretoze mi currentplayer zamkol mutex, a ostatni nedostali spravu, az kym uzivatel neurobil hod, a to je neziaduce
    SendGameReportToAllPlayer();
    for (Player* player : players)
    {
        player->InitializePrivatePlayer();
        // nasledne PrivatePlayer sa posle hracovi, aby vedel, ake ma karty
        player->SendPrivatePlayer();
    }
    while (isPlayingRound)
    {
         localCards.clear();
         conditionSignalPlayer_WaitGame.wait(lock);
         structures::PrivatePlayer privatePlayer = currentPlayer->getPrivatePlayer();
         //pripad, ze si chce/musi tahat kartu/karty     alebo sa nechce prebit v pripade, ze boli vylozene stopaky
         if (privatePlayer.numberThrowedCards == 0)
         {
             if (cardsForPull.size() != 0 && throwedCards.size() != 0)
             {
                 // ak uz nie su dostupne karty na tahanie, tak sa zoberu karty z kopy vylozenych kariet, poslena vylozena karta sa samozrejme necha, aby vedeli hraci, na aku kartu maju vykladat dalsie
                 if (cardsForPull.size() < numberCardsToPull)
                 {
                     CardType lastThrowedCard = throwedCards[throwedCards.size() - 1];
                     for (int i = throwedCards.size() - 2; i >= 0; i--)
                     {
                         cardsForPull.push_back(throwedCards[i]);
                     }
                     throwedCards.clear();
                     throwedCards.push_back(lastThrowedCard);
                 }
                 if (numberStoppedPlayers == 0)
                 {
                     // potiahne si prislusny pocet kariet (1(bezne si taha, ked nema, ale chce tahat), 3-6-9-12(napalil mu niekto sedmove karty))
                     for (int i = 0; i < numberCardsToPull; i++)
                     {
                         currentPlayer->AddCard(cardsForPull[cardsForPull.size() - 1]);
                         cardsForPull.pop_back();
                     }
                     numberCardsToPull = 1;
                 }
             }
         }
         // pripad, ze vylozil karty
         else if (privatePlayer.numberThrowedCards > 0)
         {
             for (int i = 0; i < privatePlayer.numberThrowedCards; i++)
             {
                 localCards.push_back(privatePlayer.throwedCards[i]);
             }
             if (IsCorrectThrow(localCards, localCards.size()))
             {
                 for (int i = 0; i < privatePlayer.numberThrowedCards; i++)
                 {
                     structures::Card card;
                     card.type = privatePlayer.throwedCards[i] / 4;
                     if (card.type == 0)
                     {
                         if (numberCardsToPull == 1)
                            numberCardsToPull = 3;
                         else
                            numberCardsToPull += 3;
                     }
                     else if (card.type == 7)
                         numberStoppedPlayers++;
                     currentPlayer->RemoveCard(privatePlayer.throwedCards[i]);
                     throwedCards.push_back(privatePlayer.throwedCards[i]);
                 }
             }
         }
         // v pripade, ze som hrac pokusil vyhodit nespravne karty, posle sa mu strukturav stave pre poslatim, inak sa posle aktualizovana
         // tato metoda aktualizuje premenne struktury privatePlayer z premennych objektu hraca
         currentPlayer->InitializePrivatePlayer();
         //posle sa hracovi naspat struktura, ako spatna vazba o aktualizacii hraca, cize hra skontrolovala, ci uzivatel korektne vykonal hod(tahanie, vyhodenie kariet) a nasledne aktualizovala jeho poziadavky,
           //v pripade, ze zadal zle udaje(nesedi karta a pod.), tak sa hracovi posle PrivatePlayer s Inicializovanym PrivatePlayer, cize jeho povodny stav pred hracovim poslanim struktury
         currentPlayer->SendPrivatePlayer();
         //nasledne mu posle herny report, z ktoreho sa zisti, ze ci je este aktualnym hracom(ak vykonal blbost, tak je stale na rade, ak vykonal korekny hod, tak sa pretavi aktualny hrac na dalsieho)(prestavi si svoj statePlayer)
         Player* p = currentPlayer;
         UpdateCurrentPlayer();

         p->ReportGame(CreateGameReport());
         
         conditionSignalGame_WaitPlayer.notify_all();
        //kolo skoncilo v pripade, ze sa vsetci okrem jedneho hraca nevykartali, hraci bud pokracuju v dalsom kole, podla toho, ako sa rozhodli
         int numberPlayersWaitingForNextRound = 0;
        for (Player* player : players)
        {
            if (player->getNumberCards() == 0)
                numberPlayersWaitingForNextRound++;
        }
        if (numberPlayersWaitingForNextRound >= players.size() - 1)
            isPlayingRound = false;
        
    }
    //aktualizovanie, kolko hracov este chce hrat, ak uz pocet hracov mensi, ako 2 hraci, ktory chcu hrat, tak hra sa ukonci, inak sa pokracuje v dalsom kole (medzi tym sa mozu pripojit dalsi hraci, lebo initializePlayer stale bezi)
    for (int i = 0; i < players.size(); i++)
    {
        if (!players[i]->WantPlay())
        {
            LeaveGame(players[i]);
            i = -1;
        }
    }
    if (players.size() > 2 && WantAllPlayersPlay())
    {
        _mutex.unlock();
        Run();
    }
    _mutex.unlock();
}
void Game::InitializePlayers()
{
    do
    {
        _mutex.unlock();
        socklen_t cli_lenPlayer;
        struct sockaddr_in cli_addrPlayer;
        int n;
        int sockfdPlayer;
        cli_lenPlayer = sizeof(cli_addrPlayer);
        sockfdPlayer = accept(sockfd, (struct sockaddr*)&cli_addrPlayer, &cli_lenPlayer);
        if (sockfdPlayer < 0)
        {
            perror("Error on accept!");
            continue;
        }
        bool existsNameOrErrorReading;
        char name[256];
        do
        {
            existsNameOrErrorReading = false;
            _mutex.lock();
            structures::GameReport gameReport = CreateGameReport();
            _mutex.unlock();
            //na klientovi zo zaciatku musi byt dopyt v slucke po GameReport a potom po mene, po korektnom nacitani mena uz dopyt po mene nebude, iba po objekte GameReport(to ked uz bude sa zistovat, ci chce hrat a v samotnej hre)
            n = write(sockfdPlayer, &gameReport, sizeof(struct structures::GameReport));
            if (n < 0)
            {
                perror("Error writing to socket");
                continue;
            }
            char sSockfdPlayer[256];
            strcpy(sSockfdPlayer, to_string(sockfdPlayer).c_str());
            n = write(sockfdPlayer, &sSockfdPlayer, 256);
            if (n < 0)
            {
                perror("Error writing to socket");
                existsNameOrErrorReading = true;
            }
            n = read(sockfdPlayer, name, 256);
            if (n < 0)
            {
                existsNameOrErrorReading = true;
                perror("Error reading from socket");
                continue;
            }
            //prejdenie vsetkych hracov a kontrola, ci klient nezadal existujuce meno 
            _mutex.lock(); //pristup ku zdielanej premennej players s hlavnym vlakom
            for (Player* player : players)
            {
                if (player->getName().compare(name) == 0)
                {
                    existsNameOrErrorReading = true;
                    break;
                }
            }
            _mutex.unlock();
            if (!existsNameOrErrorReading)
            {
                Player* player = new Player(this, sockfdPlayer, name, &_mutex, &conditionSignalPlayer_WaitGame, &conditionSignalGame_WaitPlayer, sockfdPlayer, cli_lenPlayer, cli_addrPlayer);
                //moze nastat situacia sucasneho pristupu z viacerych vlakien k premennej players, ku ktorej pristupujeme v podmienke while cyklu alebo pri pridavani hraca(nasledujuci riadok) 
                //a zaroven mezeme pristupit v hlavnom vlakne hry Game, kde prispupuje tiez vo while cykle(a cakame nasledne), preto treba pristup zamknut(zablokovat) a nasledne po pristupeni a docitani/zapise odblokovat
                _mutex.lock();
                //kontrola, ci este nie je presiahnuty pocet hracov
                if (players.size() < 4)
                    players.push_back(player);
                _mutex.unlock();
            }
            _mutex.lock();
            gameReport = CreateGameReport();
            _mutex.unlock();
            //na klientovi zo zaciatku musi byt dopyt v slucke po GameReport a potom po mene, po korektnom nacitani mena uz dopyt po mene nebude, iba po objekte GameReport(to ked uz bude sa zistovat, ci chce hrat a v samotnej hre)
            n = write(sockfdPlayer, &gameReport, sizeof(struct structures::GameReport));
            if (n < 0)
            {
                perror("Error writing to socket");
                existsNameOrErrorReading = true;
            }
        } while (existsNameOrErrorReading);
        _mutex.lock();
    } while (!CanRunGame() && players.size() < 4);
    _mutex.unlock();
}
bool Game::CanRunGame()
{
    return WantAllPlayersPlay() && players.size() >= 2 && players.size() <= 4;
}
bool Game::IsCorrectThrow(vector<CardType> cardTypes, int size)
{
    CardType throwedCard = throwedCards[throwedCards.size() - 1];
    bool firstCard = true;
    int numberCardsToBurned = 0; // treba 4 karty, cize vsetky karty z jedneho typu karty
    for (int i = 0; i < size; i++)
    { 
        // ci sa jedna o prvu kartu po spalenej, alebo prvu hracovu vylozenu kartu
        if (numberCardsToBurned == 0)
        {
            // pri prvej karte, ktoru hrac vyklada, bud musi sediet typ alebo farba karty
            if (firstCard)
            {
                if (!MatchCards(throwedCard, cardTypes[i], false))
                    return false;
                firstCard = false;
                numberCardsToBurned++;
            }
        }
        else
        {
            // po dalsej vylozenej karte musi sediet typ, na farbe nezalezi a po kazdej 4. karte moze ist lubovolna karta,
            // pretoze sa jednalo o spalenu, po vylozeni karty po spalenej zas musi sediet typ
            if (numberCardsToBurned < 4)
            {
                if (!MatchCards(throwedCard, cardTypes[i], true))
                    return false;
                numberCardsToBurned++;
            }
            else
            {
                numberCardsToBurned = 0;
            }
        }
        throwedCard = cardTypes[i];
    }
    return true;
}
void Game::UpdateCurrentPlayer()
{
    for (int i = 0; i < players.size(); i++)
    {
        if (players[i] == currentPlayer)
        {
            if (i == players.size() - 1)
            {
                currentPlayer = players[0];
            }
            else
            {
                currentPlayer = players[i + 1];
            }
            if (numberStoppedPlayers == 0)
                break;
            else
            {
                bool hasStop = false;
                for (int i = 0; i < currentPlayer->getNumberCards(); i++)
                {
                    structures::Card card;
                    card.type = (currentPlayer->getCards()[i] + 1) / 4;
                    if (card.type == 7)
                    {
                        hasStop = true;
                        break;
                    }
                }
                if (!hasStop)
                {
                    i = -1;
                    numberStoppedPlayers--;
                }
            }
        }
    }
}
bool Game::WantAllPlayersPlay()
{
    for (Player* player : players)
    {
        if (!player->WantPlay())
            return false;
    }
    return true;
}

bool Game::MatchCards(CardType cardType1, CardType cardType2, bool matchOnlyType)
{
    structures::Card card1;
    card1.color = cardType1 % 4;
    card1.type = cardType1 / 4;
    structures::Card card2;
    card2.color = cardType2 % 4;
    card2.type = cardType2 / 4;

    if (matchOnlyType)
        return card1.type == card2.type;
    if (card1.color == card2.color || card1.type == card2.type)
        return true;
    if (card1.type == 0 && cardType2 == CardType::Green_Bottom)
        return true;
    if (card2.type == 5)
        return true;
    return false;
}
Game::Game(int port)
{
    //Inicializacia kariet
    InitializeCards();
    //Inicializacia poctu kariet, ktory si hrac taha, ked sa dostane na tah
    numberCardsToPull = 1;
    //Inicializacia poctu stopnutych hracov
    numberStoppedPlayers = 0;
    //Inicializacia, ci sa hra herne kolo
    isPlayingRound = false;
    //vytvorenie komunikacneho kanala
    bzero((char*)&serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(4502);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
    {
        perror("Error creating socket");
        return;
    }
    if (bind(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0)
    {
        perror("Error binding socket address");
        return;
    }
    listen(sockfd, 4);
    
    tInitializePlayers = thread(&Game::InitializePlayers, this);
    //kym nie su vsetci hraci pripraveny na hru (v pocte od 2 do 4) alebo je ich menej ako 2, cakaj na signal od jednotlivych hracov, ktory potvrdia, 
    //ze chcu hrat, a ked sa zisti, ze uz potvrdil kazdy, ze chce hrat, tak opusti cyklus
    unique_lock<mutex> lock(_mutex);//zaroven uz zamkne
    while (!CanRunGame())
    {
        conditionSignalPlayer_WaitGame.wait(lock);
        SendGameReportToAllPlayer();
    }
    _mutex.unlock();
    Run();
}
Game::~Game()
{
    for (Player* player : players)
    {
        delete player;
    }
    close(sockfd);
}
int Game::GetRandomInt(int from, int to) {
    return rand() % (to - from + 1) + from;
}
double Game::GetRandomDouble(double from, double to) {
    int fromInt = from * 100;
    int toInt = to * 100;
    return ((double)(rand() % (toInt - fromInt + 1) + fromInt)) / 100;
}

structures::GameReport Game::CreateGameReport()
{
    structures::GameReport gameReport;
    gameReport.numberCardsForPull = cardsForPull.size();
    gameReport.isPlayingRound = isPlayingRound;
    gameReport.numberThrowedCards = throwedCards.size();
    gameReport.numberCardsToPull = numberCardsToPull;
    gameReport.numberStoppedPlayers = numberStoppedPlayers;
    gameReport.numberPlayers = players.size();
    if (throwedCards.size() > 0)
    {
        for (int i = 0; i < throwedCards.size(); i++)
        {
            gameReport.throwedCards[i] = throwedCards[i];
        }
    }
    for (int i = 0; i < players.size(); i++)
    {
        strcpy(gameReport.players[i].name, players[i]->getName().c_str());
        gameReport.players[i].sockfd = players[i]->getSockfdPlayer();
        gameReport.players[i].numberCards = players[i]->getNumberCards();
        gameReport.players[i].wantPlay = players[i]->WantPlay();
        gameReport.players[i].isCurrent = IsCurrentPlayer(players[i]);
    }
    return gameReport;
}

bool Game::IsCurrentPlayer(Player* player)
{
    return this->currentPlayer == player;
}

bool Game::IsGameOver(Player* player)
{
    for (Player* p : players)
    {
        if (player != p)
            if (!p->getNumberCards() == 0)
            {
                return false;
            }
    }
    return true;
}

bool Game::SendGameReportToAllPlayer()
{
    bool r = true;
    structures::GameReport gameReport = CreateGameReport();
    for (Player* player : players)
    {
        bool ret = true;
        ret = player->ReportGame(gameReport);
        if (!ret)
            r = false;
    }
    return r;
}

bool Game::getIsPlayingRound()
{
    return isPlayingRound;
}

void Game::LeaveGame(Player* player)
{
    int index = -1;
    for (int i = 0; i < players.size(); i++)
    {
        if (players[i] == player)
            index = i;
    }
    players.erase(players.begin() + index);
    delete player;
}
