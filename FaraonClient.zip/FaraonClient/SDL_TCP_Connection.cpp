#include "SDL_TCP_Connection.h"
bool SDL_TCP_Connection::InitializeSDLNet()
{
    if (SDL_Init(0) == -1) {
        printf("SDL_Init: %s\n", SDL_GetError());
        return false;
    }
    if (SDLNet_Init() == -1) {
        printf("SDLNet_Init: %s\n", SDLNet_GetError());
        return false;
    }
    return true;
}
bool SDL_TCP_Connection::SDLNetTCPOpen(const char* host, Uint16 port)
{
    printf("Starting client...\n");
    if (SDLNet_ResolveHost(&ip, "127.0.0.1", 4502) == -1) {
        printf("SDLNet_ResolveHost: %s\n", SDLNet_GetError());
        return false;
    }
    tcpsock = SDLNet_TCP_Open(&ip);
    if (!tcpsock) {
        printf("SDLNet_TCP_Open: %s\n", SDLNet_GetError());
        return false;
    }
    return true;
}
void SDL_TCP_Connection::SDLNetTCPClose()
{
    SDLNet_TCP_Close(tcpsock);
}
void SDL_TCP_Connection::SDLQuit()
{
    SDLNet_Quit();
    SDL_Quit();
}

SDL_TCP_Connection::SDL_TCP_Connection(const char* host, Uint16 port)
{
    InitializeSDLNet();
    SDLNetTCPOpen(host, port);
}

SDL_TCP_Connection::~SDL_TCP_Connection()
{
    SDLNetTCPClose();
    SDLQuit();
}
structures::GameReport SDL_TCP_Connection::ReceiveGameReport()
{
    structures::GameReport gameReport;
    int n = SDLNet_TCP_Recv(tcpsock, &gameReport, sizeof(struct structures::GameReport));
    if (n < 0)
    {
        throw new exception("Error reading from socket");
        //perror("Error reading from socket");
    }
    return gameReport;
}
structures::PrivatePlayer SDL_TCP_Connection::ReceivePrivatePlayer()
{
    structures::PrivatePlayer privatePlayer;
    int n = SDLNet_TCP_Recv(tcpsock, &privatePlayer, sizeof(struct structures::PrivatePlayer));
    if (n < 0)
    {
        throw new exception("Error reading from socket");
        //perror("Error reading from socket");
    }
    return privatePlayer;
}
bool SDL_TCP_Connection::SendMessage(string input)
{
    char message[256];
    strcpy_s(message, input.c_str());
    int n = SDLNet_TCP_Send(tcpsock, message, 256);
    if (n < 0)
    {
        throw new exception("Error sending to socket");
        //perror("Error reading from socket");
    }
    return true;
}
string SDL_TCP_Connection::ReceiveMessage()
{
    char message[256];
    int n = SDLNet_TCP_Recv(tcpsock, message, 256);
    if (n < 0)
    {
        throw new exception("Error reading from socket");
        //perror("Error reading from socket");
    }
    int i;
    string s = "";
    for (i = 0; i < 256; i++) {
        s = s + message[i];
    }
    return s;
}
int SDL_TCP_Connection::getSockfdPlayer()
{
    return sockfdPlayer;
}
void SDL_TCP_Connection::setSockfdPlayer(int sockfdPlayer)
{
    this->sockfdPlayer = sockfdPlayer;
}
bool SDL_TCP_Connection::SendPrivatePlayer(structures::PrivatePlayer privatePlayer)
{
    int n = SDLNet_TCP_Send(tcpsock, &privatePlayer, sizeof(struct structures::PrivatePlayer)); /* add 1 for the NULL */
    if (n < 0)
    {
        throw new exception("Error sending to socket");
        //perror("Error reading from socket");
    }
    return true;
}