#pragma once
#include "SDL.h"
#include "SDL_net.h"
#include <iostream>
using namespace std;
enum class CardType
{
    Red_VII,
    Ball_VII,
    Acorn_VII,
    Green_VII,
    Red_VIII,
    Ball_VIII,
    Acorn_VIII,
    Green_VIII,
    Red_IX,
    Ball_IX,
    Acorn_IX,
    Green_IX,
    Red_X,
    Ball_X,
    Acorn_X,
    Green_X,
    Red_Bottom,
    Ball_Bottom,
    Acorn_Bottom,
    Green_Bottom,
    Red_Top,
    Ball_Top,
    Acorn_Top,
    Green_Top,
    Red_King,
    Ball_King,
    Acorn_King,
    Green_King,
    Red_Stop,
    Ball_Stop,
    Acorn_Stop,
    Green_Stop,
};
namespace structures
{
    // 1. pripad: struktura, ktora sa vyuzije samostatne(jedna sa posle) v pripade, ze sa posiela smerom od klienta k serveru, 
    // ako report o tom, co klient urobil(napr. ze klikol na tlacidlo "chcem zacat hrat" alebo ze vyhodil karty a pod.),
    // pozn. zaslanie mena este nesuvisi s existenciou hraca, nakolko metoda Run objektu Player nebezi, lebo este nebol objekt Player vytvoreny, takze sa tato struktura neposiela
    // alebo naopak zo servera na klienta, v specialnych pripadoch, ked hrac na nasledujuceho hraca pouzije sedmove karty a suhrasi z ich tahanim, ak sa nechce prebit, alebo nema na prebitie prislusne karty
    struct PrivatePlayer
    {
        char name[256];
        bool wantPlay;
        //karty
        int numberCards;
        CardType cards[32];
        int numberThrowedCards;
        CardType throwedCards[32];
    };
    // 2. pripad, ked po uskutocneni 1. pripadu, ked uz dorazila sprava od klienta na server, sa struktura GameReport posiela od servera smerom ku vsetkym klientom o zmene, co sa stalo
    struct PublicPlayer
    {
        char name[256];
        int sockfd;
        bool wantPlay;
        bool isCurrent;
        //karty
        int numberCards;
    };
    // struktura, ktora sa posiela smerom zo servera ku klientom
    struct GameReport
    {
        //vsetci pripojeni hraci
        int numberPlayers;
        structures::PublicPlayer players[4];
        //pocet vyhodenych kariet na kope
        int numberThrowedCards;
        CardType throwedCards[32];
        // pocet dostupnych kariet k potiahnutiu
        int numberCardsForPull;
        // pocet kariet k potiahnutiu 
        int numberCardsToPull;
        // pocet stopakov
        int numberStoppedPlayers;
        // isPlayingRound
        bool isPlayingRound;
    };
}
class SDL_TCP_Connection
{
private:
    IPaddress ip;
    TCPsocket tcpsock;
    int sockfdPlayer;
    bool InitializeSDLNet();
    bool SDLNetTCPOpen(const char* host, Uint16 port);
    void SDLNetTCPClose();
    void SDLQuit();
public:
    SDL_TCP_Connection(const char* host, Uint16 port);
    ~SDL_TCP_Connection();
    structures::GameReport ReceiveGameReport();
    structures::PrivatePlayer ReceivePrivatePlayer();
    bool SendPrivatePlayer(structures::PrivatePlayer privatePlayer);
    bool SendMessage(string input);
    string ReceiveMessage();
    int getSockfdPlayer();
    void setSockfdPlayer(int sockfdPlayer);
};

