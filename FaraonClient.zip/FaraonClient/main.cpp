#include "SDL.h"
#include "SDL_net.h"
#include <iostream>
#include "SDL_TCP_Connection.h"
#include <thread>
#include <vector>
using namespace std;
#pragma pack(1)   // this helps to pack the struct to 5-bytes
struct packet {
    int a;
    int b;
    char meno[256];
};
#pragma pack(0)   // turn packing off




IPaddress ip;
TCPsocket tcpsock;
structures::PrivatePlayer privatePlayer;
structures::PrivatePlayer newPrivatePlayer;

void Initialize()
{
    int n;
    packet p;
    structures::GameReport gameReport;
    while (true) {
        n = SDLNet_TCP_Recv(tcpsock, &gameReport, sizeof(struct structures::GameReport));
        if (n < 0)
        {
            perror("Error reading from socket");
            continue;
        }
        printf("meno: ");
        char message[256]; // meno
        fgets(message, 256, stdin);
        int len = strlen(message);

        /* strip the newline */
        message[len - 1] = '\0';

        if (len) {
            int result;
            /* print out the message */
            printf("Sending: %.*s\n", len, message);
            p.a = 50;
            p.b = 80;
            string s = "Hovno";
            s.copy(p.meno, 5);
            result =
                SDLNet_TCP_Send(tcpsock, message, 256); /* add 1 for the NULL */
            if (result < len)
                printf("SDLNet_TCP_Send: %s\n", SDLNet_GetError());

            //n = SDLNet_TCP_Recv(tcpsock, &p, sizeof(struct packet));

        }

        if (len == 2 && tolower(message[0]) == 'q') {
            break;
        }
    }
}

enum class PlayerState
{
    Initializing,
    WaitingFromPlayerForConfirmWantPlay,
    WaitingForIsCurrentPlayer,
    WaitingForStartRound,
    IsCurrentPlayer,
    AfterPlayedRound
};


string CardTypeEnumToString(CardType card)
{
    switch (card)
    {
    case CardType::Red_VII:
        return "Red_VII";
        break;
    case CardType::Ball_VII:
        return "Ball_VII";
        break;
    case CardType::Acorn_VII:
        return "Acorn_VII";
        break;
    case CardType::Green_VII:
        return "Green_VII";
        break;
    case CardType::Red_VIII:
        return "Red_VIII";
        break;
    case CardType::Ball_VIII:
        return "Ball_VIII";
        break;
    case CardType::Acorn_VIII:
        return "Acorn_VIII";
        break;
    case CardType::Green_VIII:
        return "Green_VIII";
        break;
    case CardType::Red_IX:
        return "Red_IX";
        break;
    case CardType::Ball_IX:
        return "Ball_IX";
        break;
    case CardType::Acorn_IX:
        return "Acorn_IX";
        break;
    case CardType::Green_IX:
        return "Green_IX";
        break;
    case CardType::Red_X:
        return "Red_X";
        break;
    case CardType::Ball_X:
        return "Ball_X";
        break;
    case CardType::Acorn_X:
        return "Acorn_X";
        break;
    case CardType::Green_X:
        return "Green_X";
        break;
    case CardType::Red_Bottom:
        return "Red_Bottom";
        break;
    case CardType::Ball_Bottom:
        return "Ball_Bottom";
        break;
    case CardType::Acorn_Bottom:
        return "Acorn_Bottom";
        break;
    case CardType::Green_Bottom:
        return "Green_Bottom";
        break;
    case CardType::Red_Top:
        return "Red_Top";
        break;
    case CardType::Ball_Top:
        return "Ball_Top";
        break;
    case CardType::Acorn_Top:
        return "Acorn_Top";
        break;
    case CardType::Green_Top:
        return "Green_Top";
        break;
    case CardType::Red_King:
        return "Red_King";
        break;
    case CardType::Ball_King:
        return "Ball_King";
        break;
    case CardType::Acorn_King:
        return "Acorn_King";
        break;
    case CardType::Green_King:
        return "Green_King";
        break;
    case CardType::Red_Stop:
        return "Red_Stop";
        break;
    case CardType::Ball_Stop:
        return "Ball_Stop";
        break;
    case CardType::Acorn_Stop:
        return "Acorn_Stop";
        break;
    case CardType::Green_Stop:
        return "Green_Stop";
        break;
    default:
        break;
    }
}

void WriteMyCards()
{
    cout << "\n";
    cout << "Moje karty:" << "\n";
    for (int i = 0; i < privatePlayer.numberCards; i++)
    {
        cout << i + 1 << ". karta: " << CardTypeEnumToString(privatePlayer.cards[i]) << "\n";
    }
    cout << "\n";
}
bool OwnCard(CardType cardType)
{
    for (int i = 0; i < privatePlayer.numberCards; i++)
    {
        if (privatePlayer.cards[i] == cardType)
            return true;
    }
    return false;
}
void WriteCardNumbersTypes()
{
    cout << "\n";
    cout << "Cislo karty - typ karty:";
    for (int i = 0; i < 32; i++)
    {
        CardType c = (CardType)i;
        cout << i + 1 << " - " << CardTypeEnumToString((CardType)i) << "\n";
    }
    cout << "\n";
}
void WriteGameReport(structures::GameReport gameReport)
{
    cout << "\n";
    cout << "Herna sprava!" << "\n";
    if (gameReport.isPlayingRound)
    {
        cout << "Pocet dostupnych kariet na potiahnutie: " << gameReport.numberCardsForPull << "\n";
        cout << "Pocet vyhodenych kariet: " << gameReport.numberThrowedCards << "\n";
        cout << "Pocet tahanych kariet: " << gameReport.numberCardsToPull << "\n";
        cout << "Pocet stopnutych hracov: " << gameReport.numberStoppedPlayers << "\n";
    }
    cout << "Pocet hracov: " << gameReport.numberPlayers << "\n";
    if (gameReport.numberPlayers > 0)
    {

        cout << "Zoznam hracov: \n";
        for (int i = 0; i < gameReport.numberPlayers; i++)
        {
            cout << i + 1 << ". hrac" << "\n";
            cout << "  Meno hraca: " << gameReport.players[i].name << "\n";
            if (gameReport.isPlayingRound)
            {
                cout << "  Pocet kariet: " << gameReport.players[i].numberCards << "\n";
            }

            string wantPlay = gameReport.players[i].wantPlay ? "chcem" : "nechcem";
            cout << "  Stav 'chcem zacat hrat': " << wantPlay << "\n";
            if (gameReport.isPlayingRound)
            {
                string isCurrent = gameReport.players[i].isCurrent ? "ano" : "nie";
                cout << "  Som na rade: " << isCurrent << "\n";
            }
            cout << "\n";

        }
    }
    if (gameReport.isPlayingRound)
    {
        cout << "Pocet vyhodenych kariet: " << gameReport.numberThrowedCards << "\n";
        if (gameReport.numberThrowedCards > 0)
        {
            cout << "Zoznam vyhodenych kariet: \n";
            for (int i = 0; i < gameReport.numberThrowedCards; i++)
            {
                cout << "  " << i + 1 << ". vyhodena karta: " << CardTypeEnumToString(gameReport.throwedCards[i]) << "\n";
            }
        }
    }
    cout << "\n";
}
vector<CardType> ThrowCards()
{
    int numberCards;
    vector<CardType> cards;
    vector<CardType> remainingCardsToThrow;
    for (int i = 0; i < privatePlayer.numberCards; i++)
    {
        remainingCardsToThrow.push_back(privatePlayer.cards[i]);
    }
    WriteMyCards();
    cout << "Zadaj pocet kariet, ktore chces vyhodit:" << "\n";
    cin >> numberCards;
    int i = 0;
    while (i < numberCards)
    {
        size_t cardNumber = 0;
        for (int i = 0; i < remainingCardsToThrow.size(); i++)
        {
            cout << i + 1 << ". karta: " << CardTypeEnumToString(remainingCardsToThrow[i]) << "\n";
        }
        cout << "Zadaj poradove cislo svojej karty,  ktoru chces pridat do zoznamu vyhodenych kariet ako " << i + 1 << ". kartu v poradi:" << "\n";
        cin >> cardNumber;
        if (cardNumber > 0 && cardNumber <= remainingCardsToThrow.size())
        {
            cards.push_back(remainingCardsToThrow[cardNumber - 1]);
            i++;
            remainingCardsToThrow.erase(remainingCardsToThrow.begin() + (cardNumber - 1));
        }
        else
        {
            cout << "Zadal si poradove cislo karty mimo rozsah!" << "\n";
        }
    }
    return cards;
}
int main(int argc, char* argv[])
{
    //inicializacia
    SDL_TCP_Connection _SDL_TCP_Connection("127.0.0.1", 4502);
    structures::GameReport gameReport;
    PlayerState playerState = PlayerState::Initializing;

    //kym sa nenajdem medzi hracmi z gameReportu, tak vyzyvam k opakovanemu
    //zadaniu mena(napisem spravu, ze bud nastala chyba
    while (true/*toto je cyklus bezania aplikacie SLD, cize ten hlavny cyklus,
               v ktorom su InputUpdate, Update a Render metody, tu budem len
               simulovat Update, cize update dat z klienta na server a naopak*/)
    {
        //v metode update na klientovi sa pomocou enumu PlayerState bude
        //roznym sposobom dotazovat hrac po serveri
        if (playerState == PlayerState::Initializing)
        {
            structures::GameReport gameReport = _SDL_TCP_Connection.ReceiveGameReport();
            WriteGameReport(gameReport);
            _SDL_TCP_Connection.setSockfdPlayer(atoi(_SDL_TCP_Connection.ReceiveMessage().c_str()));
            cout << "Zadaj meno:" << "\n";
            cin >> privatePlayer.name;
            _SDL_TCP_Connection.SendMessage(privatePlayer.name);
            // aby sme overili, ci hrac nezadal existujuce meno, tak sa
            // pozrieme do reportu hry, ci sme boli zaregistrovany do zoznamu
            // hracov
            gameReport = _SDL_TCP_Connection.ReceiveGameReport();
            WriteGameReport(gameReport);
            bool exist = false;
            for (int i = 0; i < gameReport.numberPlayers; i++)
            {
                if (_SDL_TCP_Connection.getSockfdPlayer() == gameReport.players[i].sockfd)
                {
                    exist = true;
                    break;
                }
            }
            if (exist)
            {
                playerState = PlayerState::WaitingFromPlayerForConfirmWantPlay;
            }
            else
            {
                cout << "Zadal si existujuce meno!" << "\n";
            }
        }
        else if (playerState == PlayerState::WaitingFromPlayerForConfirmWantPlay)
        {
            // jeden report od objektu Player

            //ak stlacene stlacene tlacidlo alebo nieco, tak tym potvrdim, ze chcem zacat hrat
            //ja tu budem simulovat, ze dostanem hocijaky prazdny vstup
            //iba simulujem, ze po 5sekundach notifikuje, chcem zacat hrat
            cout << "Zadaj cokolvek pre potvrdenie, ze chces zacat hrat:" << "\n";
            string s;
            cin >> s;
            _SDL_TCP_Connection.SendMessage("");
            playerState = PlayerState::WaitingForStartRound;
        }
        else if (playerState == PlayerState::WaitingForStartRound)
        {
            structures::GameReport gameReport = _SDL_TCP_Connection.ReceiveGameReport();
            WriteGameReport(gameReport);
            if (gameReport.numberCardsForPull < 32 && gameReport.isPlayingRound) // karty su rozdane
            {
                // ziskam si PrivatePlayer pre ziskanie kariet
                privatePlayer = _SDL_TCP_Connection.ReceivePrivatePlayer();
                WriteMyCards();
                // nastavenie stavu, ci som na rade, alebo nie
                for (int i = 0; i < gameReport.numberPlayers; i++)
                {
                    if (_SDL_TCP_Connection.getSockfdPlayer() == gameReport.players[i].sockfd && gameReport.players[i].isCurrent)
                    {
                        playerState = PlayerState::IsCurrentPlayer;
                        break;//alebo return, ked uz to bude pisat v metode update
                    }
                    else
                    {
                        playerState = PlayerState::WaitingForIsCurrentPlayer;
                    }
                }
            }
        }
        else if (playerState == PlayerState::WaitingForIsCurrentPlayer)
        {
            //this_thread::sleep_for(chrono::seconds(3));
            cout << "Som cakajuci hrac na ineho hraca" << "\n";
            structures::GameReport gameReport = _SDL_TCP_Connection.ReceiveGameReport();
            WriteGameReport(gameReport);
            WriteMyCards();
            for (int i = 0; i < gameReport.numberPlayers; i++)
            {
                if (_SDL_TCP_Connection.getSockfdPlayer() == gameReport.players[i].sockfd)
                {
                    if (gameReport.players[i].isCurrent)
                    {
                        playerState = PlayerState::IsCurrentPlayer;
                        break;//alebo return, ked uz to bude pisat v metode update
                    }
                }
            }
        }
        else if (playerState == PlayerState::IsCurrentPlayer)
        {
            //this_thread::sleep_for(chrono::seconds(3));
            cout << "Som na rade" << "\n";
            structures::GameReport gameReport = _SDL_TCP_Connection.ReceiveGameReport();
            WriteGameReport(gameReport);
           // WriteMyCards();
            //tu v testovani zadame z konzoly
            if (gameReport.numberStoppedPlayers == 0)
            {
                cout << "Zadaj, ci chces tahat alebo vyhadzovat karty: " << "\n";
                cout << "Zadaj 1 pre tahanie kariet, 2 pre vyhadzovanie kariet" << "\n";
                int choose;
                cin >> choose;
                if (choose == 1)
                {
                    privatePlayer.numberThrowedCards = 0;
                    _SDL_TCP_Connection.SendPrivatePlayer(privatePlayer);
                }
                else
                {
                    vector<CardType> cards = ThrowCards();
                    privatePlayer.numberThrowedCards = cards.size();
                    for (int i = 0; i < cards.size(); i++)
                    {
                        privatePlayer.throwedCards[i] = cards[i];
                    }
                    _SDL_TCP_Connection.SendPrivatePlayer(privatePlayer);
                }
            }
            privatePlayer = _SDL_TCP_Connection.ReceivePrivatePlayer();
            gameReport = _SDL_TCP_Connection.ReceiveGameReport();
            WriteGameReport(gameReport);
            WriteMyCards();
            for (int i = 0; i < gameReport.numberPlayers; i++)
            {
                if (_SDL_TCP_Connection.getSockfdPlayer() == gameReport.players[i].sockfd)
                {
                    if (gameReport.players[i].numberCards == 0)
                        playerState = PlayerState::AfterPlayedRound;
                    if (!gameReport.players[i].isCurrent)
                    {
                        playerState = PlayerState::WaitingForIsCurrentPlayer;
                        break;//alebo return, ked uz to bude pisat v metode update
                    }
                }
            }
         
        }
        else if (playerState == PlayerState::AfterPlayedRound)
        {
            cout << "Zadaj y pre potvrdenie, ze chces pokracovat v dalsom kole hry:" << "\n";
            string s;
            cin >> s;
            _SDL_TCP_Connection.SendMessage(s);
            if (s.compare("y"))
                playerState = PlayerState::WaitingForStartRound;
            else
            {
                break;//exit game, uz sa mi nechce viac hrat dalsie kola
            }
        }
    }

    return 0;



    if (SDL_Init(0) == -1) {
        printf("SDL_Init: %s\n", SDL_GetError());
        exit(1);
    }
    if (SDLNet_Init() == -1) {
        printf("SDLNet_Init: %s\n", SDLNet_GetError());
        exit(2);
    }

    bool done = false;

    if (argc == 2 && strcmp(argv[1], "server") == 0) {
        printf("Starting server...\n");
        TCPsocket server, client;
        IPaddress ip;
        if (SDLNet_ResolveHost(&ip, NULL, 9999) == -1) {
            printf("SDLNet_ResolveHost: %s\n", SDLNet_GetError());
            exit(1);
        }
        server = SDLNet_TCP_Open(&ip);
        if (!server) {
            printf("SDLNet_TCP_Open: %s\n", SDLNet_GetError());
            exit(2);
        }
        while (!done) {
            /* try to accept a connection */
            client = SDLNet_TCP_Accept(server);
            if (!client) { /* no connection accepted */
              /*printf("SDLNet_TCP_Accept: %s\n",SDLNet_GetError()); */
                SDL_Delay(100); /*sleep 1/10th of a second */
                continue;
            }

            /* get the clients IP and port number */
            IPaddress* remoteip;
            remoteip = SDLNet_TCP_GetPeerAddress(client);
            if (!remoteip) {
                printf("SDLNet_TCP_GetPeerAddress: %s\n", SDLNet_GetError());
                continue;
            }

            /* print out the clients IP and port number */
            Uint32 ipaddr;
            ipaddr = SDL_SwapBE32(remoteip->host);
            printf("Accepted a connection from %d.%d.%d.%d port %hu\n", ipaddr >> 24,
                (ipaddr >> 16) & 0xff, (ipaddr >> 8) & 0xff, ipaddr & 0xff,
                remoteip->port);

            while (1) {
                /* read the buffer from client */
                char message[1024];
                int len = SDLNet_TCP_Recv(client, message, 1024);
                if (!len) {
                    printf("SDLNet_TCP_Recv: %s\n", SDLNet_GetError());
                    break;
                }
                /* print out the message */
                printf("Received: %.*s\n", len, message);
                if (message[0] == 'q') {
                    printf("Disconecting on a q\n");
                    break;
                }
                if (message[0] == 'Q') {
                    printf("Closing server on a Q.\n");
                    done = true;
                    break;
                }
            }
            SDLNet_TCP_Close(client);
        }
    }
    else if (argc == 2 && strcmp(argv[1], "client") == 0) {
        printf("Starting client...\n");
        IPaddress ip;
        TCPsocket tcpsock;

        if (SDLNet_ResolveHost(&ip, "127.0.0.1", 4502) == -1) {
            printf("SDLNet_ResolveHost: %s\n", SDLNet_GetError());
            exit(1);
        }

        tcpsock = SDLNet_TCP_Open(&ip);
        if (!tcpsock) {
            printf("SDLNet_TCP_Open: %s\n", SDLNet_GetError());
            exit(2);
        }
        int n;
        packet p;
        structures::GameReport gameReport;
        while (true) {
            n = SDLNet_TCP_Recv(tcpsock, &gameReport, sizeof(struct structures::GameReport));
            if (n < 0)
            {
                perror("Error reading from socket");
                continue;
            }
            printf("meno: ");
            char message[256]; // meno
            fgets(message, 256, stdin);
            int len = strlen(message);

            /* strip the newline */
            message[len - 1] = '\0';

            if (len) {
                int result;
                /* print out the message */
                printf("Sending: %.*s\n", len, message);
                p.a = 50;
                p.b = 80;
                string s = "Hovno";
                s.copy(p.meno, 5);
                result =
                    SDLNet_TCP_Send(tcpsock, message, 256); /* add 1 for the NULL */
                if (result < len)
                    printf("SDLNet_TCP_Send: %s\n", SDLNet_GetError());

                //n = SDLNet_TCP_Recv(tcpsock, &p, sizeof(struct packet));

            }

            if (len == 2 && tolower(message[0]) == 'q') {
                break;
            }
        }

        SDLNet_TCP_Close(tcpsock);
    }
    else {
        printf("Choose server or client\n");
    }



    // End the program
    return 0;
}
